RETROBASE 240p for Recalbox RGBDUAL
--------------------------------------------------------------------
Based and Adaptated from recalbox theme for 240p

Version : 1.1  
Author : Bounitos

## Compatibility : 
Recalbox <9 : Non tested  
Recalbox >9 : OK  

## Download
Version 1.1 : [retrobase-240p_1.1.zip]()


## Sreenshot
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview.png?raw=true)  
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_allgames.png?raw=true)
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_Atari2600.png?raw=true)
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_Atari-lynx.png?raw=true)
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_Dreamcast.png?raw=true)
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_Game-boy.png?raw=true)
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_Megadrive.png?raw=true)
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_Nintendo64.png?raw=true)
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_Sega-saturn.png?raw=true) 
![Systemeview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Systemview_Vectrex.png?raw=true)  

![Gamelistview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Gamelist.png?raw=true) 
![Gamelistview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Gamelist2.png?raw=true) 
![Gamelistview](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Gamelist3.png?raw=true) 

![Menu](https://github.com/BenoitBounar/Theme-Retrobase240p/blob/main/Screenshots/240p/v1.1/Menu.png?raw=true) 

